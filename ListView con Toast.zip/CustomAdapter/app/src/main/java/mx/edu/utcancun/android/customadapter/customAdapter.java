package mx.edu.utcancun.android.customadapter;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;






public class customAdapter extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_adapter);

        String[] wheaters = {"Monday", "Tuesday", "Wednesday","Thursday", "Friday", "Saturday","Sunday"};
        ListAdapter buckysAdapter = new custom_Adapter(this, wheaters );
        ListView buckysListView = (ListView) findViewById(R.id.buckysListView);
        buckysListView.setAdapter(buckysAdapter);

        buckysListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener(){
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String wheater = String.valueOf(parent.getItemAtPosition(position));
                        Toast.makeText(customAdapter.this, wheater, Toast.LENGTH_LONG).show();
                    }
                }
        );
    }



}
